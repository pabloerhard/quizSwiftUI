//
//  ContentView.swift
//  quiz1
//
//  Created by Alumno on 21/04/23.
//

import SwiftUI

struct ContentView: View {
    
    @State private var valorSlider = 0.5
    @State private var pickerSelection = ""
    @State private var valorToggle = true
    var colorBack = ""
    var pickerArreglo = ["Left","Right"]
    
    var body: some View {
        
        VStack {
            
        
            GeometryReader{geo in
                VStack{
                    Text("Hola").position( x: pickerSelection == "Left" ? geo.size.width * 0.1 :
                                            geo.size.width  * 0.9)
                    Picker(selection: $pickerSelection){
                        ForEach(pickerArreglo,id: \.self){ posicion in
                            Text(posicion)
                        }
                    } label: {
                        Text("Elige Posicion de Texto")
                    }
                    .pickerStyle(.segmented)
                    
                }
                .animation(.easeIn)
            }
            
            GeometryReader{ geo in
                VStack{
                    Slider(value: $valorSlider)
                        Circle()
                        .frame(width: 50,height: 50)
                        .position(x:geo.size.width * valorSlider, y:geo.size.height * 0.1)
                        .animation(.easeIn)
                    
                }
                .background(Color.teal)
            }
            
            
            HStack{
                Text("Elige Color")
                Toggle("Cambiar Color", isOn: $valorToggle)
                
                
                
            }.background(valorToggle == true ? Color.teal : Color.red)
                .animation(.easeIn)
            
                
    
            

        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
