//
//  quiz1App.swift
//  quiz1
//
//  Created by Alumno on 21/04/23.
//

import SwiftUI

@main
struct quiz1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
